#!/usr/bin/env python3
"""Turns an upstream Winlator checkout into FCDroid.

usage: apply_patches.py <upstream_dir> <project_dir>
env:   VERSION_NAME, VERSION_CODE

Every edit must actually change its target; if upstream drifts the script fails loudly
instead of silently building the wrong app.
"""
import os
import re
import shutil
import sys
from pathlib import Path

upstream = Path(sys.argv[1]).resolve()
project = Path(sys.argv[2]).resolve()
version_name = os.environ.get("VERSION_NAME", "0.1.0")
version_code = os.environ.get("VERSION_CODE", "1")

APP_ID = "app.fcdroid"


def edit(rel, fn, label):
    path = upstream / rel
    if not path.is_file():
        sys.exit(f"patch failed: {rel} not found ({label})")
    before = path.read_text(encoding="utf-8")
    after = fn(before)
    if after == before:
        sys.exit(f"patch failed: no change in {rel} ({label})")
    path.write_text(after, encoding="utf-8")
    print(f"patched {rel}: {label}")


# 1. root gradle files + overlay sources
for name in ("build.gradle", "settings.gradle", "gradle.properties"):
    shutil.copy2(project / name, upstream / name)
shutil.copytree(project / "overlay", upstream, dirs_exist_ok=True)
print("copied root gradle files and overlay")

# 2. application id / version / ABI. Java packages stay com.winlator (JNI symbols depend on it).
def gradle(s):
    s = s.replace("applicationId 'com.winlator'", f"applicationId '{APP_ID}'")
    s = re.sub(r"versionCode \d+", f"versionCode {version_code}", s, count=1)
    s = re.sub(r'versionName "[^"]*"',
               f'versionName "{version_name}"\n        ndk {{ abiFilters \'arm64-v8a\' }}', s, count=1)
    return s
edit("app/build.gradle", gradle, "applicationId, version, arm64-only")

# 3. paths that hard-code the old data dir
edit("app/src/main/java/com/winlator/container/Container.java",
     lambda s: s.replace("/data/data/com.winlator/storage", f"/data/data/{APP_ID}/storage"),
     "default E: drive path")
edit("app/src/main/java/com/winlator/core/WineUtils.java",
     lambda s: s.replace('"/com.winlator/storage"', f'"/{APP_ID}/storage"'),
     "storage link check")

# 4. name
edit("app/src/main/res/values/strings.xml",
     lambda s: s.replace('<string name="app_name">Winlator</string>', '<string name="app_name">FCDroid</string>'),
     "app name")

# 5. let our launcher activity drive the system-image installer
def installer(s):
    out = s.replace("final MainActivity activity", "final AppCompatActivity activity")
    if out.count("final AppCompatActivity activity") < 2:
        sys.exit("patch failed: ImageFsInstaller signatures not as expected")
    return out
edit("app/src/main/java/com/winlator/xenvironment/ImageFsInstaller.java", installer, "installer accepts any AppCompatActivity")

# 6. manifest: FightcadeActivity becomes the only launcher entry
def manifest(s):
    pattern = re.compile(
        r'\s*<intent-filter>\s*<action android:name="android\.intent\.action\.MAIN"\s*/>\s*'
        r'<category android:name="android\.intent\.category\.LAUNCHER"\s*/>\s*</intent-filter>')
    s2, n = pattern.subn("", s, count=1)
    if n != 1:
        sys.exit("patch failed: MainActivity launcher filter not found")
    activity = '''
        <activity android:name="com.winlator.FightcadeActivity"
            android:theme="@style/AppTheme"
            android:exported="true"
            android:screenOrientation="sensor"
            android:configChanges="keyboard|keyboardHidden|orientation|screenSize|screenLayout|smallestScreenSize|density|navigation">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
'''
    settings = '''
        <activity android:name="com.winlator.FcSettingsActivity"
            android:theme="@style/AppTheme"
            android:exported="false"
            android:screenOrientation="sensor"
            android:configChanges="keyboard|keyboardHidden|orientation|screenSize|screenLayout|smallestScreenSize|density|navigation" />
'''
    return s2.replace("    </application>", activity + settings + "    </application>", 1)
edit("app/src/main/AndroidManifest.xml", manifest, "FightcadeActivity as launcher + settings activity")

# 7. latency hooks ------------------------------------------------------------------------------
# 7a. deliver touch events as they arrive instead of batched/resampled once per frame
def touch(s):
    anchor = "public boolean onTouchEvent(MotionEvent event) {"
    if s.count(anchor) != 1:
        sys.exit("patch failed: InputControlsView.onTouchEvent anchor not unique")
    return s.replace(anchor, anchor + "\n        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) requestUnbufferedDispatch(event);")
edit("app/src/main/java/com/winlator/widget/InputControlsView.java", touch, "unbuffered touch dispatch")

# 7b. newest-frame-wins buffer queue on the GL surface
def swap(s):
    anchor = "public void onSurfaceCreated(GL10 gl, EGLConfig config) {"
    if s.count(anchor) != 1:
        sys.exit("patch failed: GLRenderer.onSurfaceCreated anchor not unique")
    return s.replace(anchor, anchor + "\n        com.winlator.FcLatency.applySwapInterval(xServerView.getContext());")
edit("app/src/main/java/com/winlator/renderer/GLRenderer.java", swap, "swap interval 0")

# 7c. highest refresh rate on the game screen
def window(s):
    pattern = re.compile(r"(AppUtils\.keepScreenOn\(this\);)(\s*setContentView\(R\.layout\.xserver_display_activity\);)")
    out, n = pattern.subn(r"\1\n        FcLatency.applyWindow(this);\2", s, count=1)
    if n != 1:
        sys.exit("patch failed: XServerDisplayActivity.onCreate anchor not found")
    return out
edit("app/src/main/java/com/winlator/XServerDisplayActivity.java", window, "max refresh rate")

print("all patches applied")
