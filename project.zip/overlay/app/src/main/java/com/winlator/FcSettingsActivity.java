package com.winlator;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.xenvironment.ImageFs;

/** One screen for everything a player may want to change: touch controls, speed and latency. */
public class FcSettingsActivity extends AppCompatActivity {
    private static final String[] RES_LABELS = {"Fast (640x360)", "Balanced (854x480)", "Sharp (1280x720)"};
    private static final String[] RES_VALUES = {"640x360", "854x480", "1280x720"};
    private static final String[] PRESET_LABELS = {"Performance (fastest)", "Intermediate", "Stability (safest)"};
    private static final String[] PRESET_VALUES = {"PERFORMANCE", "INTERMEDIATE", "STABILITY"};
    private static final String[] GPU_LABELS = {"Auto (detect GPU)", "VirGL + WineD3D (any GPU)", "Turnip + DXVK (Adreno GPUs only)"};
    private static final String[] DIR_LABELS = {"D-pad", "Stick"};

    private Container container;
    private CheckBox cbControls, cbLatency, cbFps;
    private Spinner spDirection, spResolution, spPreset, spGpu;
    private SeekBar sbScale, sbOpacity;
    private TextView tvScale, tvOpacity;

    // ------------------------------------------------------------------ UI helpers

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, int sizeSp, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sizeSp);
        tv.setTextColor(color);
        return tv;
    }

    private TextView header(String value) {
        TextView tv = text(value, 17, Color.parseColor("#7FB2FF"));
        tv.setPadding(0, dp(22), 0, dp(6));
        return tv;
    }

    private CheckBox check(String label, boolean checked) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setTextColor(Color.WHITE);
        cb.setButtonTintList(ColorStateList.valueOf(Color.WHITE));
        cb.setChecked(checked);
        return cb;
    }

    private Spinner spinner(String[] labels, int selected) {
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, labels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View row = super.getView(position, convertView, parent);
                ((TextView)row).setTextColor(Color.WHITE);
                return row;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adapter);
        sp.setSelection(Math.max(0, Math.min(selected, labels.length - 1)));
        return sp;
    }

    private interface Formatter { String format(int value); }

    private SeekBar slider(int min, int max, int value, final TextView label, final String prefix, final Formatter fmt) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        label.setText(prefix + fmt.format(value));
        final int base = min;
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                label.setText(prefix + fmt.format(progress + base));
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        return sb;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private static int indexOf(String[] values, String wanted, int fallback) {
        for (int i = 0; i < values.length; i++) if (values[i].equals(wanted)) return i;
        return fallback;
    }

    // ------------------------------------------------------------------ screen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            if (ImageFs.find(this).isValid()) {
                for (Container c : new ContainerManager(this).getContainers()) {
                    if (FightcadeActivity.CONTAINER_NAME.equals(c.getName())) {
                        container = c;
                        break;
                    }
                }
            }
        }
        catch (Throwable ignored) {}

        FcConfig.ensureProfile(this);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(14), dp(20), dp(24));

        root.addView(text("Settings", 26, Color.WHITE));

        // ---- touch controls
        root.addView(header("On-screen controls"));
        cbControls = check("Show touch controls in game", FcConfig.controlsEnabled(this));
        root.addView(cbControls);

        root.addView(text("Direction control", 14, Color.parseColor("#C9CED8")));
        spDirection = spinner(DIR_LABELS, FcConfig.directionIsStick(this) ? 1 : 0);
        root.addView(spDirection);

        tvScale = text("", 14, Color.parseColor("#C9CED8"));
        tvScale.setPadding(0, dp(10), 0, 0);
        root.addView(tvScale);
        sbScale = slider(FcConfig.SCALE_MIN, FcConfig.SCALE_MAX, FcConfig.scalePercent(this), tvScale, "Button size: ", (v) -> v + "%");
        root.addView(sbScale);

        tvOpacity = text("", 14, Color.parseColor("#C9CED8"));
        tvOpacity.setPadding(0, dp(10), 0, 0);
        root.addView(tvOpacity);
        int opacity = Math.round(FcConfig.prefs(this).getFloat(FcConfig.PREF_OPACITY, 0.4f) * 100);
        sbOpacity = slider(10, 100, Math.max(10, Math.min(100, opacity)), tvOpacity, "Opacity: ", (v) -> v + "%");
        root.addView(sbOpacity);

        root.addView(button("Edit layout (drag and resize buttons)", (v) -> {
            applyControlSettings(false);
            Intent intent = new Intent(this, ControlsEditorActivity.class);
            intent.putExtra("profile_id", FcConfig.PROFILE_ID);
            startActivity(intent);
        }));
        root.addView(button("Reset layout to default", (v) -> {
            FcConfig.resetProfile(this);
            spDirection.setSelection(0);
            sbScale.setProgress(100 - FcConfig.SCALE_MIN);
            Toast.makeText(this, "Layout reset", Toast.LENGTH_SHORT).show();
        }));

        TextView keys = text(
            "Default keys (set the same keys in Fightcade's input mapping, or change them in the layout editor):\n" +
            "Direction: arrow keys\n" +
            "LP MP HP: A S D     LK MK HK: Z X C\n" +
            "Coin: 5     Start: 1\n" +
            "Extra buttons: Q W E R", 13, Color.parseColor("#9AA3B2"));
        keys.setPadding(0, dp(10), 0, 0);
        root.addView(keys);

        // ---- speed / latency
        root.addView(header("Speed and latency"));
        cbLatency = check("Low-latency mode (newest-frame display, max refresh rate, vsync off in the guest)", FcConfig.lowLatency(this));
        root.addView(cbLatency);

        if (container == null) {
            root.addView(text("Run the first-time setup from the main screen to unlock the options below.", 14, Color.parseColor("#E0A458")));
        }
        else {
            root.addView(text("Resolution (lower is faster)", 14, Color.parseColor("#C9CED8")));
            spResolution = spinner(RES_LABELS, indexOf(RES_VALUES, container.getScreenSize(), 1));
            root.addView(spResolution);

            root.addView(text("CPU translation (Box64 preset)", 14, Color.parseColor("#C9CED8")));
            spPreset = spinner(PRESET_LABELS, indexOf(PRESET_VALUES, container.getBox64Preset(), 0));
            root.addView(spPreset);

            root.addView(text("Graphics", 14, Color.parseColor("#C9CED8")));
            spGpu = spinner(GPU_LABELS, 0);
            root.addView(spGpu);
            root.addView(text("Current: " + container.getGraphicsDriver() + " + " + container.getDXWrapper(), 12, Color.parseColor("#9AA3B2")));

            cbFps = check("Show FPS counter", container.isShowFPS());
            root.addView(cbFps);
        }

        root.addView(button("Save", (v) -> save()));
        root.addView(button("Cancel", (v) -> finish()));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#14161C"));
        scroll.addView(root);
        setContentView(scroll);
    }

    // ------------------------------------------------------------------ apply

    private void applyControlSettings(boolean persistToggles) {
        FcConfig.prefs(this).edit()
            .putFloat(FcConfig.PREF_OPACITY, (sbOpacity.getProgress() + 10) / 100f)
            .apply();
        boolean stick = spDirection.getSelectedItemPosition() == 1;
        if (stick != FcConfig.directionIsStick(this)) FcConfig.applyDirection(this, stick);
        FcConfig.applyScale(this, sbScale.getProgress() + FcConfig.SCALE_MIN);
        if (persistToggles) {
            FcConfig.prefs(this).edit()
                .putBoolean(FcConfig.PREF_CONTROLS, cbControls.isChecked())
                .putBoolean(FcConfig.PREF_LOW_LATENCY, cbLatency.isChecked())
                .apply();
        }
    }

    private void save() {
        applyControlSettings(true);

        if (container != null) {
            container.setScreenSize(RES_VALUES[spResolution.getSelectedItemPosition()]);
            String preset = PRESET_VALUES[spPreset.getSelectedItemPosition()];
            container.setBox64Preset(preset);
            container.setBox86Preset(preset);

            int gpu = spGpu.getSelectedItemPosition();
            boolean turnip = gpu == 2 || (gpu == 0 && FcConfig.isAdreno(this));
            container.setGraphicsDriver(turnip ? "turnip" : "virgl");
            container.setDXWrapper(turnip ? "dxvk" : "wined3d");
            container.setShowFPS(cbFps.isChecked());
            container.setEnvVars(FcConfig.withEnvVar(container.getEnvVars(), "vblank_mode", cbLatency.isChecked() ? "0" : null));
            container.saveData();
        }

        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        finish();
    }
}
