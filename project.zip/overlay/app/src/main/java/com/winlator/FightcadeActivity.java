package com.winlator;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.core.FileUtils;
import com.winlator.core.GPUInformation;
import com.winlator.xenvironment.ImageFs;
import com.winlator.xenvironment.ImageFsInstaller;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Single-purpose front door: prepares the Wine/Box64 system image, creates one tuned
 * "Fightcade" container, fetches Fightcade on first run (never bundled) and launches it.
 * Fightcade's own files are never modified.
 */
public class FightcadeActivity extends AppCompatActivity {
    private static final String TAG = "FCDroid";
    private static final int REQ_STORAGE = 77;
    static final String CONTAINER_NAME = "Fightcade";
    private static final String MARKER = ".fcdroid-installed";
    private static final String[] LAUNCHER_EXES = {"fightcade2.exe", "fc2-electron.exe"};
    private static final String EMULATOR_EXE = "fcadefbneo.exe";

    private TextView statusView;
    private ProgressBar progressBar;
    private Button launchButton, emulatorButton, settingsButton, reinstallButton, advancedButton, retryButton;

    private volatile boolean busy = false;
    private volatile boolean ready = false;
    private Container container;
    private File launcherShortcut, emulatorShortcut;

    // ------------------------------------------------------------------ UI

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();

        if (hasStoragePermission()) startSetup();
        else {
            status("Storage permission is needed to read ROMs from Downloads/FightcadeROMs.", -1);
            ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_STORAGE) startSetup(); // continue either way; ROM import just becomes a no-op
    }

    private boolean hasStoragePermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density);
    }

    private Button makeButton(String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        button.setVisibility(View.GONE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        button.setLayoutParams(lp);
        return button;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(16), dp(24), dp(16));
        root.setBackgroundColor(Color.parseColor("#14161C"));

        TextView title = new TextView(this);
        title.setText("FCDroid");
        title.setTextSize(30);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        statusView = new TextView(this);
        statusView.setTextColor(Color.parseColor("#C9CED8"));
        statusView.setTextSize(15);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, dp(16), 0, dp(12));
        root.addView(statusView);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setIndeterminate(true);
        root.addView(progressBar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        launchButton = makeButton("Launch Fightcade", (v) -> launch(launcherShortcut));
        emulatorButton = makeButton("Launch emulator only (offline / testing)", (v) -> launch(emulatorShortcut));
        settingsButton = makeButton("Settings (touch controls, speed, latency)", (v) -> startActivity(new Intent(this, FcSettingsActivity.class)));
        reinstallButton = makeButton("Reinstall Fightcade", (v) -> reinstall());
        advancedButton = makeButton("Advanced (full Winlator menus)", (v) -> startActivity(new Intent(this, MainActivity.class)));
        retryButton = makeButton("Retry", (v) -> startSetup());
        root.addView(launchButton);
        root.addView(emulatorButton);
        root.addView(settingsButton);
        root.addView(reinstallButton);
        root.addView(advancedButton);
        root.addView(retryButton);

        setContentView(root);
    }

    private void status(final String message, final int progress) {
        runOnUiThread(() -> {
            statusView.setText(message);
            if (progress < 0) progressBar.setIndeterminate(true);
            else {
                progressBar.setIndeterminate(false);
                progressBar.setProgress(progress);
            }
        });
    }

    private void showButtons(final boolean ready, final boolean failed) {
        runOnUiThread(() -> {
            progressBar.setVisibility(ready || failed ? View.GONE : View.VISIBLE);
            launchButton.setVisibility(ready && launcherShortcut != null ? View.VISIBLE : View.GONE);
            emulatorButton.setVisibility(ready && emulatorShortcut != null ? View.VISIBLE : View.GONE);
            settingsButton.setVisibility(ready || failed ? View.VISIBLE : View.GONE);
            reinstallButton.setVisibility(ready || failed ? View.VISIBLE : View.GONE);
            advancedButton.setVisibility(ready || failed ? View.VISIBLE : View.GONE);
            retryButton.setVisibility(failed ? View.VISIBLE : View.GONE);
        });
    }

    // ------------------------------------------------------------------ setup flow

    @Override
    protected void onResume() {
        super.onResume();
        // Coming back from Settings: rewrite the shortcuts so "show touch controls" takes effect.
        if (ready && container != null && !busy) {
            try {
                writeShortcuts(getFightcadeDir());
            }
            catch (Throwable t) {
                Log.w(TAG, "shortcut refresh failed", t);
            }
        }
    }

    private void startSetup() {
        if (busy) return;
        busy = true;
        ready = false;
        showButtons(false, false);
        new Thread(() -> {
            try {
                setup();
            }
            catch (Throwable t) {
                Log.e(TAG, "setup failed", t);
                status("Setup failed:\n" + t.getMessage(), 0);
                showButtons(false, true);
            }
            finally {
                busy = false;
            }
        }, "fcdroid-setup").start();
    }

    private void setup() throws Exception {
        status("Preparing Wine + Box64 system files (first run only, can take a few minutes)...", -1);
        ensureImageFs();

        status("Creating the Fightcade container...", -1);
        container = ensureContainer();
        FcConfig.ensureProfile(this);

        File fcDir = getFightcadeDir();
        if (!new File(fcDir, MARKER).isFile()) installFightcade(fcDir);

        syncRoms(fcDir);
        writeShortcuts(fcDir);

        String msg = "Ready.";
        if (launcherShortcut == null) {
            msg += "\n\nThis Fightcade package has no Windows launcher (Fightcade2.exe / fc2-electron.exe), so only the emulator can be started. " +
                   "Drop a Windows Fightcade .zip into Downloads and press Reinstall to use it instead.";
        }
        msg += "\n\nROMs: copy .zip ROMs into Downloads/FightcadeROMs, they are imported on each start.";
        status(msg, 100);
        ready = true;
        showButtons(true, false);
    }

    private File getFightcadeDir() {
        return new File(container.getRootDir(), ".wine/drive_c/Fightcade");
    }

    private static boolean imageReady(ImageFs fs) {
        try {
            return fs.isValid() && fs.getVersion() >= ImageFsInstaller.LATEST_VERSION;
        }
        catch (Exception e) {
            return false;
        }
    }

    private void ensureImageFs() throws Exception {
        final ImageFs fs = ImageFs.find(this);
        if (imageReady(fs)) return;

        runOnUiThread(() -> ImageFsInstaller.installIfNeeded(this)); // shows its own progress dialog

        long deadline = System.currentTimeMillis() + 25 * 60 * 1000L;
        while (System.currentTimeMillis() < deadline) {
            Thread.sleep(700);
            if (imageReady(fs)) {
                Thread.sleep(1500); // let the installer finish its post-install bookkeeping
                return;
            }
        }
        throw new IllegalStateException("Installing the system image timed out or failed. Free some storage and retry.");
    }

    private Container ensureContainer() throws Exception {
        final ContainerManager manager = new ContainerManager(this);
        for (Container existing : manager.getContainers()) {
            if (CONTAINER_NAME.equals(existing.getName())) return existing;
        }

        final JSONObject data = buildContainerData();
        final AtomicReference<Container> result = new AtomicReference<>();
        final CountDownLatch latch = new CountDownLatch(1);
        // createContainerAsync builds a Handler, so it must be called from the main thread
        runOnUiThread(() -> manager.createContainerAsync(data, (created) -> {
            result.set(created);
            latch.countDown();
        }));

        if (!latch.await(10, TimeUnit.MINUTES) || result.get() == null) {
            throw new IllegalStateException("Could not create the Wine container (not enough free storage?).");
        }
        return result.get();
    }

    /** Defaults tuned for FBNeo + weak SoCs; Adreno phones get Turnip/DXVK, everything else VirGL/WineD3D. */
    private JSONObject buildContainerData() throws Exception {
        boolean adreno = FcConfig.isAdreno(this);

        String cpus = pickFastCores();
        JSONObject data = new JSONObject();
        data.put("name", CONTAINER_NAME);
        data.put("envVars", FcConfig.withEnvVar(Container.DEFAULT_ENV_VARS, "vblank_mode", FcConfig.lowLatency(this) ? "0" : null));
        data.put("screenSize", adreno ? "1280x720" : "854x480");
        data.put("graphicsDriver", adreno ? "turnip" : "virgl");
        data.put("dxwrapper", adreno ? "dxvk" : "wined3d");
        data.put("box64Preset", "PERFORMANCE");
        data.put("box86Preset", "PERFORMANCE");
        data.put("cpuList", cpus);
        data.put("cpuListWoW64", cpus);
        return data;
    }

    /** Comma list of the highest-capacity CPU cores (big cores), or all cores when that can't be read. */
    private static String pickFastCores() {
        int count = Runtime.getRuntime().availableProcessors();
        long[] score = new long[count];
        long best = 0;
        for (int i = 0; i < count; i++) {
            score[i] = readLong("/sys/devices/system/cpu/cpu" + i + "/cpu_capacity");
            if (score[i] <= 0) score[i] = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            best = Math.max(best, score[i]);
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (best > 0 && score[i] != best) continue;
            if (sb.length() > 0) sb.append(',');
            sb.append(i);
        }
        // Pinning to a single core would starve Wine's helper threads; fall back to everything.
        if (sb.indexOf(",") < 0) {
            sb.setLength(0);
            for (int i = 0; i < count; i++) {
                if (i > 0) sb.append(',');
                sb.append(i);
            }
        }
        return sb.toString();
    }

    private static long readLong(String path) {
        try {
            return Long.parseLong(FileUtils.readLines(new File(path)).get(0).trim());
        }
        catch (Throwable t) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ Fightcade install

    private File findLocalArchive() {
        try {
            File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File[] files = downloads.listFiles();
            if (files == null) return null;
            File best = null;
            for (File f : files) {
                String n = f.getName().toLowerCase(Locale.ENGLISH);
                if (!f.isFile() || !n.startsWith("fightcade") || n.contains("rom")) continue;
                if (!(n.endsWith(".zip") || n.endsWith(".tar.gz") || n.endsWith(".tgz"))) continue;
                if (best == null || f.lastModified() > best.lastModified()) best = f;
            }
            return best;
        }
        catch (Throwable t) {
            return null;
        }
    }

    private void installFightcade(File fcDir) throws IOException {
        File archive;
        String name;
        boolean downloaded = false;

        File local = findLocalArchive();
        if (local != null) {
            archive = local;
            name = local.getName().toLowerCase(Locale.ENGLISH);
            status("Using " + local.getName() + " from Downloads...", -1);
        }
        else {
            String url = getString(R.string.fightcade_url);
            name = url.substring(url.lastIndexOf('/') + 1).toLowerCase(Locale.ENGLISH);
            archive = new File(getCacheDir(), "fightcade-download.bin");
            status("Downloading Fightcade from the official site...", 0);
            download(url, archive);
            downloaded = true;
        }

        status("Unpacking Fightcade...", -1);
        if (fcDir.exists()) FileUtils.delete(fcDir);
        fcDir.mkdirs();
        if (name.endsWith(".zip")) extractZip(archive, fcDir);
        else extractTarGz(archive, fcDir);

        if (downloaded) archive.delete();
        FileUtils.writeString(new File(fcDir, MARKER), "ok");
    }

    private void download(String url, File dest) throws IOException {
        HttpURLConnection conn = (HttpURLConnection)new URL(url).openConnection();
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(30000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "FCDroid/1.0");
        try {
            int code = conn.getResponseCode();
            if (code != 200) {
                throw new IOException("Download failed (HTTP " + code + "). You can instead put a Fightcade .zip in Downloads and press Retry.");
            }
            long total = conn.getContentLength();
            long done = 0;
            int lastPercent = -1;
            byte[] buffer = new byte[64 * 1024];
            try (InputStream in = conn.getInputStream(); OutputStream out = new FileOutputStream(dest)) {
                int n;
                while ((n = in.read(buffer)) > 0) {
                    out.write(buffer, 0, n);
                    done += n;
                    if (total > 0) {
                        int percent = (int)(done * 100 / total);
                        if (percent != lastPercent) {
                            lastPercent = percent;
                            status("Downloading Fightcade... " + percent + "%", percent);
                        }
                    }
                }
            }
        }
        finally {
            conn.disconnect();
        }
    }

    private static String normalize(String name) {
        name = name.replace('\\', '/');
        while (name.startsWith("./")) name = name.substring(2);
        while (name.startsWith("/")) name = name.substring(1);
        return name;
    }

    /** "Top/" when every entry sits under one top-level folder, otherwise "". */
    private static String commonRoot(List<String> names) {
        String root = null;
        for (String raw : names) {
            String n = normalize(raw);
            if (n.isEmpty()) continue;
            int slash = n.indexOf('/');
            if (slash < 0) return "";
            String first = n.substring(0, slash + 1);
            if (root == null) root = first;
            else if (!root.equals(first)) return "";
        }
        return root == null ? "" : root;
    }

    private static File safeChild(File destDir, String relative) throws IOException {
        File out = new File(destDir, relative);
        String base = destDir.getCanonicalPath() + File.separator;
        return out.getCanonicalPath().startsWith(base) ? out : null; // blocks ../ (zip-slip)
    }

    private static void copyStream(InputStream in, File dest) throws IOException {
        File parent = dest.getParentFile();
        if (parent != null) parent.mkdirs();
        try (OutputStream out = new FileOutputStream(dest)) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        }
    }

    private static void extractZip(File archive, File destDir) throws IOException {
        try (ZipFile zip = new ZipFile(archive)) {
            List<String> names = new ArrayList<>();
            for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements(); ) names.add(e.nextElement().getName());
            String root = commonRoot(names);

            for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements(); ) {
                ZipEntry entry = e.nextElement();
                String rel = normalize(entry.getName());
                if (rel.startsWith(root)) rel = rel.substring(root.length());
                if (rel.isEmpty()) continue;
                File out = safeChild(destDir, rel);
                if (out == null) continue;
                if (entry.isDirectory()) out.mkdirs();
                else try (InputStream in = zip.getInputStream(entry)) {
                    copyStream(in, out);
                }
            }
        }
    }

    private static TarArchiveInputStream openTar(File archive) throws IOException {
        return new TarArchiveInputStream(new GzipCompressorInputStream(new BufferedInputStream(new FileInputStream(archive))));
    }

    private static void extractTarGz(File archive, File destDir) throws IOException {
        List<String> names = new ArrayList<>();
        try (TarArchiveInputStream tar = openTar(archive)) {
            TarArchiveEntry entry;
            while ((entry = tar.getNextTarEntry()) != null) names.add(entry.getName());
        }
        String root = commonRoot(names);

        try (TarArchiveInputStream tar = openTar(archive)) {
            TarArchiveEntry entry;
            while ((entry = tar.getNextTarEntry()) != null) {
                if (entry.isSymbolicLink() || entry.isLink()) continue;
                String rel = normalize(entry.getName());
                if (rel.startsWith(root)) rel = rel.substring(root.length());
                if (rel.isEmpty()) continue;
                File out = safeChild(destDir, rel);
                if (out == null) continue;
                if (entry.isDirectory()) out.mkdirs();
                else copyStream(tar, out);
            }
        }
    }

    // ------------------------------------------------------------------ ROMs + shortcuts

    private void syncRoms(File fcDir) {
        try {
            File src = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "FightcadeROMs");
            if (!src.isDirectory()) {
                src.mkdirs(); // so the folder is visible to the user
                return;
            }
            File[] files = src.listFiles();
            if (files == null) return;

            File dst = new File(fcDir, "ROMs");
            dst.mkdirs();
            for (File f : files) {
                if (!f.isFile() || !f.getName().toLowerCase(Locale.ENGLISH).endsWith(".zip")) continue;
                File target = new File(dst, f.getName());
                if (target.isFile() && target.length() == f.length()) continue;
                status("Importing ROM " + f.getName() + "...", -1);
                try (InputStream in = new FileInputStream(f)) {
                    copyStream(in, target);
                }
            }
        }
        catch (Throwable t) {
            Log.w(TAG, "ROM import skipped", t);
        }
    }

    private void collect(File dir, int depth, List<File> out) {
        File[] children = dir.listFiles();
        if (children == null || depth > 6) return;
        for (File f : children) {
            if (f.isDirectory()) collect(f, depth + 1, out);
            else out.add(f);
        }
    }

    private File findExe(List<File> files, String... lowerNames) {
        for (String wanted : lowerNames) {
            File best = null;
            for (File f : files) {
                if (!f.getName().equalsIgnoreCase(wanted)) continue;
                if (best == null || f.getPath().length() < best.getPath().length()) best = f;
            }
            if (best != null) return best;
        }
        return null;
    }

    private void writeShortcuts(File fcDir) {
        List<File> files = new ArrayList<>();
        collect(fcDir, 0, files);

        File desktopDir = container.getDesktopDir();
        desktopDir.mkdirs();

        File launcherExe = findExe(files, LAUNCHER_EXES);
        File emulatorExe = findExe(files, EMULATOR_EXE);
        launcherShortcut = launcherExe != null ? writeShortcut(desktopDir, "Fightcade", launcherExe) : null;
        emulatorShortcut = emulatorExe != null ? writeShortcut(desktopDir, "Fightcade FBNeo", emulatorExe) : null;

        if (launcherShortcut == null && emulatorShortcut == null) {
            throw new IllegalStateException("No Fightcade executables were found after unpacking. Press Reinstall, or put a Windows Fightcade .zip in Downloads first.");
        }
    }

    private File writeShortcut(File desktopDir, String name, File exe) {
        String driveC = new File(container.getRootDir(), ".wine/drive_c").getAbsolutePath();
        String relative = exe.getAbsolutePath().substring(driveC.length() + 1);
        String unixPath = ImageFs.WINEPREFIX + "/dosdevices/c:/" + relative.replace(" ", "\\ ");

        String content = "[Desktop Entry]\n" +
            "Name=" + name + "\n" +
            "Exec=env WINEPREFIX=\"" + ImageFs.WINEPREFIX + "\" wine " + unixPath + "\n" +
            "Type=Application\n" +
            "StartupNotify=true\n";
        if (FcConfig.controlsEnabled(this)) {
            // Winlator reads this and shows our fighting layout as soon as the game screen opens
            content += "\n[Extra Data]\ncontrolsProfile=" + FcConfig.PROFILE_ID + "\n";
        }
        File file = new File(desktopDir, name + ".desktop");
        FileUtils.writeString(file, content);
        return file;
    }

    // ------------------------------------------------------------------ actions

    private void launch(File shortcut) {
        if (shortcut == null || container == null) return;
        Intent intent = new Intent(this, XServerDisplayActivity.class);
        intent.putExtra("container_id", container.id);
        intent.putExtra("shortcut_path", shortcut.getPath());
        startActivity(intent);
    }

    private void reinstall() {
        if (busy || container == null) return;
        new File(getFightcadeDir(), MARKER).delete();
        startSetup();
    }
}
