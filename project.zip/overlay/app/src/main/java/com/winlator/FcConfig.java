package com.winlator;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.preference.PreferenceManager;

import com.winlator.core.FileUtils;
import com.winlator.core.GPUInformation;
import com.winlator.inputcontrols.ControlsProfile;
import com.winlator.inputcontrols.InputControlsManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.Locale;

/** Shared settings keys plus the fighting-game touch layout (a regular Winlator controls profile). */
public final class FcConfig {
    /** High id so it never collides with Winlator's bundled profiles (1..3) or ones users create later. */
    public static final int PROFILE_ID = 100;
    public static final String PROFILE_NAME = "Fightcade (fighting layout)";

    public static final String PREF_CONTROLS = "fc_controls_enabled";
    public static final String PREF_STICK = "fc_dir_stick";
    public static final String PREF_SCALE = "fc_btn_scale";          // percent, 100 = default size
    public static final String PREF_LOW_LATENCY = "fc_low_latency";
    public static final String PREF_OPACITY = "overlay_opacity";     // Winlator's own key, read by the game screen

    // Above ~120% the fixed default positions start to touch; larger buttons are a job for the layout editor.
    public static final int SCALE_MIN = 60, SCALE_MAX = 120;

    private FcConfig() {}

    public static SharedPreferences prefs(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static boolean controlsEnabled(Context c) { return prefs(c).getBoolean(PREF_CONTROLS, true); }
    public static boolean directionIsStick(Context c) { return prefs(c).getBoolean(PREF_STICK, false); }
    public static boolean lowLatency(Context c) { return prefs(c).getBoolean(PREF_LOW_LATENCY, true); }
    public static int scalePercent(Context c) { return prefs(c).getInt(PREF_SCALE, 100); }

    public static boolean isAdreno(Context context) {
        try {
            String renderer = GPUInformation.getRenderer(context);
            return renderer != null && renderer.toLowerCase(Locale.ENGLISH).contains("adreno");
        }
        catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ env var helper

    /** Sets (value != null) or removes (value == null) KEY=value inside a space-separated env string. */
    public static String withEnvVar(String envVars, String key, String value) {
        StringBuilder sb = new StringBuilder();
        for (String token : envVars.trim().split("\\s+")) {
            if (token.isEmpty() || token.startsWith(key + "=")) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(token);
        }
        if (value != null) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(key).append('=').append(value);
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ touch layout

    private static JSONObject element(String type, String shape, String[] bindings, String text,
                                      double x, double y, double scale) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("type", type);
        o.put("shape", shape);
        JSONArray b = new JSONArray();
        for (String s : bindings) b.put(s);
        o.put("bindings", b);
        o.put("scale", scale);
        o.put("x", x);
        o.put("y", y);
        o.put("toggleSwitch", false);
        o.put("text", text);
        o.put("iconId", 0);
        return o;
    }

    private static String[] key(String binding) {
        return new String[]{binding, "NONE", "NONE", "NONE"};
    }

    /**
     * Default layout, normalised 0..1 like every Winlator profile. Keys are plain keyboard presses, so they are
     * mapped inside Fightcade (Map game inputs) like a normal keyboard:
     *   direction  : arrow keys
     *   LP MP HP   : A S D        LK MK HK : Z X C
     *   Coin / Start : 5 / 1      extras : Q W E R
     * Side areas are used on purpose: a 4:3 game on a wide phone leaves empty bars there.
     */
    public static void writeDefaultProfile(Context context) {
        try {
            boolean stick = directionIsStick(context);
            double s = scalePercent(context) / 100.0;

            JSONArray els = new JSONArray();
            els.put(element(stick ? "STICK" : "D_PAD", "CIRCLE",
                new String[]{"KEY_UP", "KEY_RIGHT", "KEY_DOWN", "KEY_LEFT"}, "", 0.125, 0.64, s));

            // three columns x two rows, punches on top, kicks below (arcade order)
            double[] cols = {0.745, 0.835, 0.925};
            String[] top = {"KEY_A", "KEY_S", "KEY_D"};
            String[] topText = {"LP", "MP", "HP"};
            String[] bottom = {"KEY_Z", "KEY_X", "KEY_C"};
            String[] bottomText = {"LK", "MK", "HK"};
            for (int i = 0; i < 3; i++) {
                els.put(element("BUTTON", "CIRCLE", key(top[i]), topText[i], cols[i], 0.50, s));
                els.put(element("BUTTON", "CIRCLE", key(bottom[i]), bottomText[i], cols[i], 0.76, s));
            }

            // four extra keys for whatever the player maps in Fightcade (macros, 3P/3K, taunt ...)
            double[] extraX = {0.70, 0.78, 0.86, 0.94};
            String[] extra = {"KEY_Q", "KEY_W", "KEY_E", "KEY_R"};
            for (int i = 0; i < 4; i++) {
                els.put(element("BUTTON", "RECT", key(extra[i]), "", extraX[i], 0.24, 0.8 * s));
            }

            els.put(element("BUTTON", "RECT", key("KEY_5"), "COIN", 0.06, 0.09, 0.8 * s));
            els.put(element("BUTTON", "RECT", key("KEY_1"), "START", 0.14, 0.09, 0.8 * s));

            JSONObject data = new JSONObject();
            data.put("id", PROFILE_ID);
            data.put("name", PROFILE_NAME);
            data.put("cursorSpeed", 1.0);
            data.put("elements", els);
            FileUtils.writeString(ControlsProfile.getProfileFile(context, PROFILE_ID), data.toString());
        }
        catch (JSONException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Creates our profile once; never overwrites the user's edits. */
    public static synchronized void ensureProfile(Context context) {
        // Winlator copies its own bundled profiles only into an empty folder, so let it do that first.
        new InputControlsManager(context).getProfiles();
        if (!ControlsProfile.getProfileFile(context, PROFILE_ID).isFile()) writeDefaultProfile(context);
    }

    public static synchronized void resetProfile(Context context) {
        prefs(context).edit().putBoolean(PREF_STICK, false).putInt(PREF_SCALE, 100).apply();
        writeDefaultProfile(context);
    }

    private static JSONObject readProfile(Context context) throws JSONException {
        return new JSONObject(FileUtils.readString(ControlsProfile.getProfileFile(context, PROFILE_ID)));
    }

    private static void saveProfile(Context context, JSONObject data) {
        FileUtils.writeString(ControlsProfile.getProfileFile(context, PROFILE_ID), data.toString());
    }

    /** Switches the direction control between D-pad and stick, keeping its position and key bindings. */
    public static synchronized void applyDirection(Context context, boolean stick) {
        ensureProfile(context);
        try {
            JSONObject data = readProfile(context);
            JSONArray els = data.getJSONArray("elements");
            for (int i = 0; i < els.length(); i++) {
                JSONObject e = els.getJSONObject(i);
                String type = e.getString("type");
                if (type.equals("D_PAD") || type.equals("STICK")) e.put("type", stick ? "STICK" : "D_PAD");
            }
            saveProfile(context, data);
        }
        catch (JSONException ignored) {}
        prefs(context).edit().putBoolean(PREF_STICK, stick).apply();
    }

    /** Rescales every control relative to the previous setting so manual layout edits survive. */
    public static synchronized void applyScale(Context context, int newPercent) {
        ensureProfile(context);
        int oldPercent = scalePercent(context);
        if (newPercent != oldPercent && oldPercent > 0) {
            try {
                double ratio = newPercent / (double)oldPercent;
                JSONObject data = readProfile(context);
                JSONArray els = data.getJSONArray("elements");
                for (int i = 0; i < els.length(); i++) {
                    JSONObject e = els.getJSONObject(i);
                    double scaled = Math.max(0.3, Math.min(2.5, e.getDouble("scale") * ratio));
                    e.put("scale", scaled);
                }
                saveProfile(context, data);
            }
            catch (JSONException ignored) {}
        }
        prefs(context).edit().putInt(PREF_SCALE, newPercent).apply();
    }
}
