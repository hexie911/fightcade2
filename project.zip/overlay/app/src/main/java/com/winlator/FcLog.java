package com.winlator;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Environment;
import android.os.SystemClock;
import android.util.Log;

import com.winlator.core.Callback;
import com.winlator.core.ProcessHelper;
import com.winlator.xenvironment.ImageFs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Writes everything needed to diagnose a failed start to Downloads/FCDroid/last-run.log. Winlator restarts the whole
 * app as soon as the guest process ends, which wipes its own in-memory log, so this log goes to a file immediately.
 * Hooked in by scripts/apply_patches.py; every method is failure-proof so logging can never break a run.
 */
public final class FcLog {
    private static final String TAG = "FCDroid";
    private static final long MAX_BYTES = 6L * 1024 * 1024;

    private static PrintWriter writer;
    private static long written;
    private static long startMs;
    private static Callback<String> sink;

    private FcLog() {}

    // ------------------------------------------------------------------ file handling

    private static File[] candidates(Context context) {
        List<File> list = new ArrayList<>();
        try {
            File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            list.add(new File(new File(downloads, "FCDroid"), "last-run.log"));
        }
        catch (Throwable ignored) {}
        try {
            File ext = context.getExternalFilesDir(null);
            if (ext != null) list.add(new File(ext, "last-run.log"));
        }
        catch (Throwable ignored) {}
        list.add(new File(context.getFilesDir(), "last-run.log"));
        return list.toArray(new File[0]);
    }

    private static synchronized void open(Context context) {
        close();
        for (File file : candidates(context)) {
            try {
                File parent = file.getParentFile();
                if (parent != null) parent.mkdirs();
                writer = new PrintWriter(new FileWriter(file, false), true);
                written = 0;
                return;
            }
            catch (Throwable ignored) {}
        }
    }

    private static synchronized void close() {
        if (writer != null) {
            try { writer.close(); } catch (Throwable ignored) {}
            writer = null;
        }
        if (sink != null) {
            ProcessHelper.removeDebugCallback(sink);
            sink = null;
        }
    }

    /** Where the log lives, for showing to the user; null if there is none yet. */
    public static String logPath(Context context) {
        for (File file : candidates(context)) if (file.isFile()) return file.getPath().replaceFirst("^/storage/emulated/0/", "");
        return null;
    }

    /** One line summarising how the previous run ended, or null when there is no log. */
    public static String lastRunNote(Context context) {
        for (File file : candidates(context)) {
            if (!file.isFile()) continue;
            try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
                long length = raf.length();
                long from = Math.max(0, length - 96 * 1024);
                raf.seek(from);
                byte[] buffer = new byte[(int)(length - from)];
                raf.readFully(buffer);
                String exit = null;
                for (String line : new String(buffer, "UTF-8").split("\n")) {
                    if (line.startsWith("== guest process exited")) exit = line.substring(3).trim();
                }
                return exit != null ? exit : "no exit recorded (the app may have been killed)";
            }
            catch (Throwable t) {
                return null;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ writing

    public static synchronized void line(String text) {
        try {
            Log.i(TAG, text);
            if (writer == null || written > MAX_BYTES) return;
            writer.println(text);
            written += text.length() + 1;
        }
        catch (Throwable ignored) {}
    }

    private static long mb(long bytes) {
        return bytes / (1024 * 1024);
    }

    private static void describe(Context context, File root, String relative) {
        File f = new File(root, relative);
        line("  " + relative + ": exists=" + f.exists() + " size=" + f.length() + " exec=" + f.canExecute());
    }

    /** Called from XServerDisplayActivity.onCreate, before the guest is started. */
    public static void begin(Context context) {
        try {
            boolean on = FcConfig.debugLog(context);
            // Winlator prints Box64 diagnostics only when its own preference is set; we own that switch.
            FcConfig.prefs(context).edit().putBoolean("enable_box86_64_logs", on).commit();
            if (!on) return;

            startMs = SystemClock.elapsedRealtime();
            open(context);
            sink = FcLog::line;
            ProcessHelper.addDebugCallback(sink);

            line("== FCDroid debug log, " + new Date());
            try {
                PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                line("app: " + info.versionName + " (" + info.versionCode + ") " + context.getPackageName());
            }
            catch (Throwable ignored) {}
            line("device: " + Build.MANUFACTURER + " " + Build.MODEL + " | hardware=" + Build.HARDWARE + " | board=" + Build.BOARD);
            line("android: " + Build.VERSION.RELEASE + " (sdk " + Build.VERSION.SDK_INT + "), patch " + Build.VERSION.SECURITY_PATCH);
            line("abis: " + Arrays.toString(Build.SUPPORTED_ABIS) + " | cores: " + Runtime.getRuntime().availableProcessors());
            line("kernel: " + System.getProperty("os.version"));
            try {
                ActivityManager am = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                line("ram: total " + mb(mi.totalMem) + " MB, available " + mb(mi.availMem) + " MB, lowMemory=" + mi.lowMemory);
            }
            catch (Throwable ignored) {}
            line("free app storage: " + mb(context.getFilesDir().getUsableSpace()) + " MB");

            final String nativeDir = context.getApplicationInfo().nativeLibraryDir;
            line("native lib dir: " + nativeDir);
            for (String lib : new String[]{"libproot.so", "libproot-loader.so", "libproot-loader32.so", "libwinlator.so", "libvirglrenderer.so"}) {
                File f = new File(nativeDir, lib);
                line("  " + lib + ": exists=" + f.exists() + " size=" + f.length() + " exec=" + f.canExecute());
            }

            final ImageFs fs = ImageFs.find(context);
            final File root = fs.getRootDir();
            String version;
            try { version = String.valueOf(fs.getVersion()); } catch (Throwable t) { version = "unreadable"; }
            line("imagefs: valid=" + fs.isValid() + " version=" + version + " root=" + root);
            for (String p : new String[]{"usr/bin/env", "usr/local/bin/box64", "opt/wine/bin/wine64", "opt/wine/bin/wine-wow64", "usr/lib/aarch64-linux-gnu/ld-2.31.so"}) {
                describe(context, root, p);
            }

            // Standalone check that proot can run a guest binary at all; off the UI thread so startup is not delayed.
            final File tmp = fs.getTmpDir();
            new Thread(() -> probeProot(nativeDir, root, tmp), "fcdroid-probe").start();
        }
        catch (Throwable t) {
            Log.w(TAG, "log setup failed", t);
        }
    }

    private static void probeProot(String nativeDir, File root, File tmp) {
        try {
            tmp.mkdirs();
            ProcessBuilder pb = new ProcessBuilder(
                nativeDir + "/libproot.so", "--kill-on-exit", "--rootfs=" + root.getPath(), "--cwd=/",
                "--bind=/dev", "--bind=/proc", "--bind=/sys", "/usr/bin/env", "echo", "fcdroid-proot-ok");
            pb.environment().clear();
            pb.environment().put("PROOT_TMP_DIR", tmp.getPath());
            pb.environment().put("PROOT_LOADER", nativeDir + "/libproot-loader.so");
            pb.environment().put("PROOT_LOADER_32", nativeDir + "/libproot-loader32.so");
            pb.environment().put("LD_LIBRARY_PATH", "/usr/lib/aarch64-linux-gnu");
            pb.redirectErrorStream(true);
            Process p = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            if (!p.waitFor(8, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                line("probe proot: TIMED OUT after 8 s");
            }
            else line("probe proot: exit=" + p.exitValue());
            String l;
            int n = 0;
            while (reader.ready() && (l = reader.readLine()) != null && n++ < 30) line("  | " + l);
        }
        catch (Throwable t) {
            line("probe proot: FAILED to start: " + t);
        }
    }

    /** Called from the guest-exit callback right before Winlator restarts the app. */
    public static void guestExited(int status) {
        try {
            long seconds = (SystemClock.elapsedRealtime() - startMs) / 1000;
            line("== guest process exited: status=" + status + " after ~" + seconds + " s");
            dumpLogcat();
        }
        catch (Throwable ignored) {}
        finally {
            close();
        }
    }

    private static void dumpLogcat() {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"logcat", "-d", "-v", "threadtime", "-t", "500"});
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            line("== android log (this app only, last 500 lines)");
            String l;
            int n = 0;
            while ((l = reader.readLine()) != null && n++ < 600) line(l);
            p.destroy();
        }
        catch (Throwable t) {
            line("logcat unavailable: " + t);
        }
    }

    /** Extra Wine output so an immediate failure explains itself. */
    public static String wineDebugDefault(Context context) {
        return FcConfig.debugLog(context) ? "err+all" : "-all";
    }
}
