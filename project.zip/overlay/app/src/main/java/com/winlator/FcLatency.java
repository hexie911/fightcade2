package com.winlator;

import android.app.Activity;
import android.content.Context;
import android.opengl.EGL14;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;

/**
 * Display-side latency tweaks, wired into Winlator's game screen by scripts/apply_patches.py.
 * Everything is best-effort: any failure is swallowed so it can never stop the game from starting.
 */
public final class FcLatency {
    private FcLatency() {}

    /** Ask for the display's highest refresh rate at the current resolution (no effect on 60 Hz-only panels). */
    public static void applyWindow(Activity activity) {
        if (!FcConfig.lowLatency(activity)) return;
        try {
            Window window = activity.getWindow();
            Display display = activity.getWindowManager().getDefaultDisplay();
            Display.Mode current = display.getMode();
            Display.Mode best = current;
            for (Display.Mode mode : display.getSupportedModes()) {
                boolean sameSize = mode.getPhysicalWidth() == current.getPhysicalWidth() &&
                                   mode.getPhysicalHeight() == current.getPhysicalHeight();
                if (sameSize && mode.getRefreshRate() > best.getRefreshRate()) best = mode;
            }
            if (best.getModeId() != current.getModeId()) {
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.preferredDisplayModeId = best.getModeId();
                window.setAttributes(lp);
            }
        }
        catch (Throwable ignored) {}
    }

    /**
     * Call on the GL thread. Swap interval 0 puts the buffer queue in "newest frame wins" mode, so a frame is not
     * stuck waiting behind older ones (up to two frames of delay with the default queue).
     */
    public static void applySwapInterval(Context context) {
        if (!FcConfig.lowLatency(context)) return;
        try {
            EGL14.eglSwapInterval(EGL14.eglGetCurrentDisplay(), 0);
        }
        catch (Throwable ignored) {}
    }
}
