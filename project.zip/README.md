# FCDroid

Fightcade 2 on Android through Wine + Box64, as one dedicated app. It does not modify, repackage or
reverse-engineer Fightcade: the app downloads Fightcade from the official site on first run and runs it as-is.

The Wine/Box64/X-server runtime is the MIT-licensed Winlator v9.0.0 source. CI fetches it at build time, so
this project only holds the small Fightcade-specific layer on top:

| Piece | What it does |
|---|---|
| `overlay/.../FightcadeActivity.java` | The only launcher screen. Installs the system image, creates a tuned "Fightcade" container, downloads/unpacks Fightcade, imports ROMs, launches |
| `overlay/.../FcSettingsActivity.java`, `FcConfig.java` | Settings screen and the fighting-game touch layout generator |
| `overlay/.../FcLatency.java` | Refresh-rate and buffer-queue latency tweaks, hooked in by the patch script |
| `scripts/apply_patches.py` | Rebrands to `app.fcdroid`, makes the new activity the launcher, arm64-only. Fails the build if upstream changed under it |
| `build.gradle`, `settings.gradle`, `gradle.properties` | Upstream ships no root Gradle files, so these are supplied here |
| `.github/workflows/build.yml` | Builds, signs and publishes the APK as a GitHub release |

## Setup (phone-only, from the GitHub website)

1. Create a repository on GitHub.
2. **Add file > Upload files**: upload `project.zip` to the repo root (do not unzip it).
3. **Add file > Create new file**, name it `.github/workflows/build.yml`, paste the contents of `build.yml`, commit.
4. Optional but recommended (lets new builds install over old ones): **Settings > Secrets and variables > Actions**, add
   `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` from `signing-secrets.txt`.
   Without them every build uses a throwaway key and you must uninstall before installing the next one.
5. The push in step 3 starts the build (about 15-30 min the first time). Open **Releases** for the APK, or **Actions > build-log** if it failed.

To release a numbered version, create a tag such as `v0.1.0`; otherwise each push publishes `build-N`.

## Using it

- First launch: grants storage, unpacks the Wine system (a few minutes), downloads Fightcade.
- ROMs: put the `.zip` ROMs in `Downloads/FightcadeROMs`. They are copied in on every start.
- No launcher in the package? Put a Windows Fightcade `.zip` named `Fightcade*.zip` in Downloads and press **Reinstall**.
- **Launch emulator only** starts FBNeo directly (offline play, training mode, checking performance).
- **Advanced** opens the full Winlator UI (container settings, Box64 presets, controller bindings, touch layouts).

## Settings and touch controls

**Settings** on the main screen has everything in one place:

- Show or hide the touch controls, direction control **D-pad or Stick**, button size (60-120%), opacity.
- **Edit layout** opens Winlator's drag-and-resize editor on the fighting layout; **Reset layout** restores the default.
- Resolution, Box64 preset, graphics driver, FPS counter, and the low-latency switch.

The default layout is a normal Winlator controls profile ("Fightcade (fighting layout)"). Every button is a plain keyboard
key, so you map them in Fightcade's input settings exactly like a keyboard:

| Control | Key |
|---|---|
| Direction (D-pad or stick) | arrow keys |
| LP MP HP (top row) | A S D |
| LK MK HK (bottom row) | Z X C |
| Coin / Start | 5 / 1 |
| 4 extra buttons | Q W E R |

The side areas are used on purpose, because a 4:3 game on a wide phone leaves empty bars there.
Keys that only exist as text labels can be rebound in the layout editor.

## Input-lag work

What is changed (all switchable with Settings > Low-latency mode, except the first):

1. Touch events are delivered unbuffered (`requestUnbufferedDispatch`), not batched once per frame.
2. The GL surface uses swap interval 0 (newest frame wins instead of queueing behind older ones).
3. The display's highest refresh rate at the current resolution is requested (only matters on 90/120 Hz phones).
4. `vblank_mode=0` in the guest so Mesa never waits for a vsync that Android already handles.
5. Box64 PERFORMANCE preset, big cores pinned, low default resolution.

Already fast upstream: audio uses AAudio low-latency mode and the screen redraws only on change.
None of this has been measured on a device. For netplay the biggest lever is still Fightcade's own frame-delay and
a wired or 5 GHz connection.

## Defaults for weak phones (realme C21-Y: Unisoc T610, Mali-G52)

Mali has no Turnip driver, so non-Adreno devices get VirGL + WineD3D at 854x480, Box64 PERFORMANCE preset and
the big cores pinned when the kernel reports them. Adreno devices get Turnip + DXVK at 1280x720.
If something crashes, open Advanced and switch the container's Box64 preset to STABILITY.

## Known unknowns (not testable without a device)

- The first build has not been run: CI will tell us what to fix, send me the `build-log`.
- The default download is Fightcade's Linux tarball (the only official URL I could confirm). Its Electron launcher is a
  Linux binary and cannot run under Wine, so until a Windows package is supplied only the emulator starts.
- The Electron launcher is heavy under Box64 on a T610; online play through it may not be practical on that phone.
- Sideload only: Winlator targets API 28 so Wine may execute from app storage, which Google Play does not accept.
